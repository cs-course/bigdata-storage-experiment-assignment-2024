clang++ main.cpp MurmurHash2.cpp -o main -O3 -Wall
./main >> log.txt

echo "Execution fin."