#include<bits/stdc++.h>
#include<chrono>
#include<random>
#include"MurmurHash2.h"
using namespace std;

class Timer {
public:
    Timer() :
            m_beg(clock_::now()) {
    }
    void reset() {
        m_beg = clock_::now();
    }

    double elapsed() const {
        return std::chrono::duration<double, std::milli>(
                clock_::now() - m_beg).count();
    }

private:
    typedef std::chrono::high_resolution_clock clock_;
    typedef std::chrono::duration<double, std::ratio<1> > second_;
    std::chrono::time_point<clock_> m_beg;
};

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count()); // 64bit mt19937_64
int rand_int(int l, int r) {
    assert(l<=r);
    return uniform_int_distribution<int>(l,r)(rng); // 返回l到r中的一个随机整数
}
long long rand_ll(long long l, long long r) {
    assert(l<=r);
    return uniform_int_distribution<long long>(l,r)(rng);
}

class Cuckoo {
private:
    struct HashFunction {
        uint a, b, m;
        uint get(unsigned long long x) {
            return (1ull*a*x + b) % m + 1;
        }
    };

    int TimeStamp;
    int Buckets, BucketSize;
    int TotalSize;

    struct MurmurFunction {
        uint32_t seed = rand_int(INT_MIN, INT_MAX);
        uint32_t m;
        MurmurFunction(uint32_t m): m(m) {}
        uint32_t get(long long x) {
            return MurmurHash2(&x, sizeof(long long), seed)%(m - 1) + 1;
        }
    };

    vector<long long> dataAccumulation;
    vector<vector<long long>> data;
    vector<long long> extraData;
    vector<vector<bool>> occupied;
    vector<vector<vector<pair<int, int>>>> alt; // Element's toward edge.
    vector<vector<int>> lastVisited; // Tag array.
    vector<vector<pair<int, int>>> fromVisited; // Tag array for bfs.
    vector<HashFunction> hashes;
    // vector<MurmurFunction> hashes;

    int BFSReconstructThreshold = 0;
    int CuckooReconstructThresholdK = 0;

    int Elements = 0;

    int S_Insert = 0;
    int F_Insert = 0;
    double TotalTime_Insert = 0;
    int Insert_Times = 0;
    int Swap_Times = 0;
    
    int S_Query = 0;
    int F_Query = 0;
    double TotalTime_Query = 0;
    int Query_Times = 0;

    double TotalTime_Reconstruct = 0;

    vector<pair<int, int>> caculate_alts(long long data) {
        vector<pair<int, int>> result;
        for(int i=0; i<Buckets; i++) {
            result.push_back({
                i,
                hashes[i].get(data)
            });
        }
        return result;
    }

    bool naive_dfs(int bucket, int idx) {
        lastVisited[bucket][idx] = TimeStamp;
        if(!occupied[bucket][idx]) return true;

        for(auto to:alt[bucket][idx])
            if(to.first != bucket && lastVisited[to.first][to.second] != TimeStamp) {
                if(naive_dfs(to.first, to.second)) {
                    Swap_Times ++;
                    // printf("Move from %d,%d to %d,%d\n", bucket, idx, to.first, to.second);
                    occupied[to.first][to.second] = true;
                    occupied[bucket][idx] = false;
                    data[to.first][to.second] = data[bucket][idx];
                    alt[to.first][to.second] = alt[bucket][idx];
                    return true;
                }
            }
        return false;
    }

    bool naive_bfs(int bucket, int idx) {
        // cerr<<"START BFS"<<endl;
        queue<pair<int, int>> qu;
        qu.push({bucket, idx});
        lastVisited[bucket][idx] = TimeStamp;
        fromVisited[bucket][idx] = {0,0};
        int searched_nodes = 0;
        while(!qu.empty()) {
            searched_nodes ++;
            assert(searched_nodes < TotalSize);
            auto x = qu.front();
            qu.pop();
            assert(alt[x.first][x.second].size() == Buckets);
            for(auto to: alt[x.first][x.second])
                if(to != x && lastVisited[to.first][to.second] != TimeStamp) {
                    if(!occupied[to.first][to.second]) {
                        auto nx = x;
                        auto nt = to;
                        while(nx.second) {
                            // cerr<<"SWAPPING"<<Swap_Times<<' '<<searched_nodes<<endl;
                            Swap_Times ++;
                            occupied[nt.first][nt.second] = true;
                            occupied[nx.first][nx.second] = false;
                            data[nt.first][nt.second] = data[nx.first][nx.second];
                            alt[nt.first][nt.second] = alt[nx.first][nx.second];
                            nt = nx;
                            nx = fromVisited[nx.first][nx.second];
                        }
                        assert(nt == (pair<int,int>(bucket, idx)));
                        return true;
                    }

                    fromVisited[to.first][to.second] = x;
                    lastVisited[to.first][to.second] = TimeStamp;
                    qu.push(to);
                }
        }
        // cerr<<"FAILED"<<searched_nodes<<endl;
        return false;
    }

    bool naive_bfs_impl_extra(int bucket, int idx) {
        assert(occupied[bucket][idx]);
        queue<pair<int, int>> qu;
        qu.push({bucket, idx});
        lastVisited[bucket][idx] = TimeStamp;
        fromVisited[bucket][idx] = {0,0};
        vector<pair<int,int>> nodes;
        while(!qu.empty() && nodes.size() < BFSReconstructThreshold) {
            auto x = qu.front();
            qu.pop();
            nodes.push_back(x);
            assert(alt[x.first][x.second].size() == Buckets);
            for(auto to: alt[x.first][x.second])
                if(to != x) {
                    if(lastVisited[to.first][to.second] != TimeStamp) {
                        if(!occupied[to.first][to.second]) {
                            auto nx = x;
                            auto nt = to;
                            do {
                                assert(!occupied[nt.first][nt.second]);
                                Swap_Times ++;
                                occupied[nt.first][nt.second] = true;
                                occupied[nx.first][nx.second] = false;
                                data[nt.first][nt.second] = data[nx.first][nx.second];
                                alt[nt.first][nt.second] = alt[nx.first][nx.second];
                                nt = nx;
                                nx = fromVisited[nx.first][nx.second];
                            } while(nx.second);
                            assert(nt == (pair<int,int>(bucket, idx)));
                            return true;
                        }
                        lastVisited[to.first][to.second] = TimeStamp;
                        fromVisited[to.first][to.second] = x;
                        qu.push(to);
                    }
                    else {
                        nodes.push_back(to);
                    }
                }
        }

        // Randomly choose an alternate point.
        int ridx = rand_int(0, nodes.size() - 1);

        // Break the ring.
        auto nt = nodes[ridx];
        auto nx = fromVisited[nt.first][nt.second];
        extraData.push_back(data[nt.first][nt.second]);
        occupied[nt.first][nt.second]=false;

        while(nx.second) {
            assert(!occupied[nt.first][nt.second]);
            Swap_Times ++;
            occupied[nt.first][nt.second] = true;
            occupied[nx.first][nx.second] = false;
            data[nt.first][nt.second] = data[nx.first][nx.second];
            alt[nt.first][nt.second] = alt[nx.first][nx.second];
            nt = nx;
            nx = fromVisited[nx.first][nx.second];
        }

        return false;
    }

    void new_time() {
        TimeStamp ++;
    } 

public:

    Cuckoo(int buckets, int bucket_size):Buckets(buckets), BucketSize(bucket_size) {
        TotalSize = buckets * bucket_size;
        BFSReconstructThreshold = ceil(pow(buckets, 2));
        for(int i=0; i<buckets; i++) {
            data.push_back(vector<long long>(bucket_size));
            lastVisited.push_back(vector<int>(bucket_size));
            fromVisited.push_back(vector<pair<int, int>>(bucket_size));
            occupied.push_back(vector<bool>(bucket_size));
            alt.push_back(vector<vector<pair<int,int>>>(bucket_size));
            // hashes.push_back(MurmurFunction(bucket_size));
            auto hash = HashFunction({1u*rand_int(0x3f3f3f3f, 0x7fffffff), 1u*rand_int(0x3f3f3f3f, 0x7fffffff), 1u*bucket_size-1});
            // printf("Create hash: %d %d %d\n", hash.a, hash.b, hash.m);
            hashes.push_back(hash);
        }
    }

    double occupancy() { return (double)Elements / TotalSize; }
    // Insert operations per ms
    double ips() { return Insert_Times / TotalTime_Insert; }
    double irps() { return (Insert_Times) / (TotalTime_Insert + TotalTime_Reconstruct); }
    double insert_total_time() { return TotalTime_Insert; }
    double reconstruct_total_time() { return TotalTime_Reconstruct; }
    int insert_count() { return Insert_Times; }
    int insert_failed_count() { return F_Insert; }
    int swap_count() { return Swap_Times; }
    // Query operations per ms
    double qps() { return Query_Times / TotalTime_Query; }
    double query_total_time() { return TotalTime_Query; }
    int query_count() { return Query_Times; }
    int query_failed_count() { return F_Query; }


    bool insert(long long idata, bool reconstructing = false) {
        new_time();
        Insert_Times ++;
        bool success = false;
        Timer timer;
        timer.reset();

        for(int i=0; i<Buckets; i++) {
            int x = hashes[i].get(idata);
            if(occupied[i][x]) {
                success = naive_bfs_impl_extra(i, x);
            }
            else success = true;
            if(!occupied[i][x]) {
                data[i][x] = idata;
                alt[i][x] = caculate_alts(idata);
                occupied[i][x] = true;
                break;
            }
        }

        if(!reconstructing) {
            dataAccumulation.push_back(idata);
            TotalTime_Insert += timer.elapsed();
            if(success) {
                S_Insert ++;
                Elements ++;
            }
            else F_Insert ++;
            if(Elements * CuckooReconstructThresholdK > TotalSize + 2)
                reconstruct();
        }

        return success;
    }

    bool query(const long long idata) {
        Query_Times++;
        bool result = false;
        
        Timer timer;
        timer.reset();
        for(int i=0; i<Buckets && !result; i++)
            if(idata == data[i][hashes[i].get(idata)])
                result = true;
        if(!result) {
            for(auto x: extraData) {
                if(x == idata) {
                    result = true;
                    break;
                }
            }
        }

        TotalTime_Query += timer.elapsed();
        if(result) S_Query ++;
        else F_Query ++;

        return result;
    }

    // Reconstruct the cuckoo hash map.
    void reconstruct() {
        Timer timer;
        timer.reset();

        BucketSize *= CuckooReconstructThresholdK;
        TotalSize *= CuckooReconstructThresholdK;

        data.clear();
        lastVisited.clear();
        fromVisited.clear();
        occupied.clear();
        alt.clear();
        hashes.clear();
        extraData.clear();
        for(int i=0; i<Buckets; i++) {
            data.push_back(vector<long long>(BucketSize));
            lastVisited.push_back(vector<int>(BucketSize));
            fromVisited.push_back(vector<pair<int, int>>(BucketSize));
            occupied.push_back(vector<bool>(BucketSize));
            alt.push_back(vector<vector<pair<int,int>>>(BucketSize));
            // hashes.push_back(MurmurFunction(BucketSize));
            auto hash = HashFunction({1u*rand_int(0x3f3f3f3f, 0x7fffffff), 1u*rand_int(0x3f3f3f3f, 0x7fffffff), 1u*BucketSize-1});
            // printf("Create hash: %d %d %d\n", hash.a, hash.b, hash.m);
            hashes.push_back(hash);
        }

        // Reinsert.
        for(long long x: dataAccumulation)
            insert(x, true);

        TotalTime_Reconstruct += timer.elapsed();
    }
};

const int IT = 2e6;
const int B = 8, BS = IT/B;
Cuckoo cuckoo(B, BS);

const string TN = "reconstruction cuckoo";

int main() {
    
    vector<long long> rows;
    for(int i=0; i<IT; i++) {
        long long x=rand_ll(0, 0x7fffffffffffffffll);
        if(i%1000==0)
            cerr<<"PROGRESS"<<1.0*i/IT<<endl;
        cuckoo.insert(x);
        rows.push_back(x);
    }

    printf("Buckets - %d / Bucket Size - %d\n", B, BS);
    printf("Task name - %s\n", TN.c_str());
    cout<<"Insert operations count: " << cuckoo.insert_count()<<endl;
    cout<<"Insert failed operations count: " << cuckoo.insert_failed_count()<<endl;
    cout<<"Insert failed ratio: " << 1.0 * cuckoo.insert_failed_count() / cuckoo.insert_count() <<endl;
    cout<<"Insert operations total cost time(ms): " << cuckoo.insert_total_time() <<endl;
    cout<<"Insert operations per second: " << cuckoo.ips() * 1000 <<endl;
    cout<<"Reconstruct total cost time(ms): " <<  cuckoo.reconstruct_total_time() <<endl;
    cout<<"Insert(With Reconstruct) operations per second: " << cuckoo.irps() * 1000 <<endl;
    cout<<"Cuckoo Occupancy: " << cuckoo.occupancy()<<endl;
    printf("Conflict Swap Times: %d\n", cuckoo.swap_count());


    // Randomize query order.
    shuffle(rows.begin(), rows.end(), rng);
    cerr<<"Querying..."<<endl;
    for(auto x:rows) cuckoo.query(x);

    cout<<"Query failed ratio: "<< 1.0 * cuckoo.query_failed_count() / cuckoo.query_count() <<endl;
    cout<<"Query operations total cost time(ms): " << cuckoo.query_total_time()<<endl;
    cout<<"Query operations per second: " << cuckoo.qps() * 1000 <<endl;

    // Test for unordered_set.
    unordered_multiset<long long> uset;
    cout<<"Test unordered set... Inserting ..."<<endl;
    Timer timer;
    timer.reset();
    for(auto x:rows) uset.insert(x);
    cout<<"IPS: "<<1.0 * rows.size() / timer.elapsed() * 1000<<endl;
    cout<<"Querying..."<<endl;
    shuffle(rows.begin(), rows.end(), rng);
    timer.reset();
    for(auto x:rows)
        if(uset.find(x) == uset.end()) cerr<<"FAILED."<<endl;
    cout<<"QPS: "<<1.0 * rows.size() / timer.elapsed() * 1000<<endl;

    cout<<endl;


    return 0;
}